# Horinova — Arch Linux Edition (0.2.0)

This is a cross-platform C# / Avalonia port of the original Windows Horinova browser. The original Windows source is kept in `WindowsOriginal/`. The Linux port uses Avalonia's `NativeWebView` with the system WebKitGTK backend; it is **not Chromium/CefSharp**.

## Features in this early port

- Dark Horinova-inspired window and navigation toolbar
- Address bar: HTTP/HTTPS URLs, domain shortcuts, and DuckDuckGo search
- Back, forward, reload, and home controls
- Multiple tabs and close-tab control
- A private-tab mode that skips writing visited URLs to Horinova history
- Persistent browsing history with a clear-history action
- Simple URL-based download dialog, saving files to `~/Downloads/Horinova`
- Settings dialog for the home page
- Linux-friendly .NET 8 / Avalonia project and GitHub Actions build

## Important limitations

- This is an early port; it is **not yet feature-parity** with the Windows app.
- Private tabs currently skip Horinova's history log only. They do **not guarantee cookie/cache isolation** or erase data held by the system WebKit engine. Do not treat this as full private browsing.
- The download dialog downloads a URL directly with `HttpClient`; it is not yet integrated with normal browser download links, and it does not share browser login cookies.
- The original ad/tracker filter, password store, automatic update checker, and complete settings UI have not yet been ported.
- Website rendering is provided by WebKitGTK, so behavior can differ from Chromium-based browsers.

## Install dependencies on Arch Linux

For building from source:

```bash
sudo pacman -Syu
sudo pacman -S --needed dotnet-sdk gtk3 webkit2gtk-4.1 libsoup3
```

For running a previously built framework-dependent app, install `dotnet-runtime` plus the native WebKit dependencies.

## Run from source

Extract the ZIP, open a terminal in `Horinova-Arch`, then run:

```bash
chmod +x run-arch.sh build-arch.sh
dotnet restore Horinova.Arch.csproj
./run-arch.sh
```

## Build a Linux x64 release

```bash
./build-arch.sh
```

Then run:

```bash
dotnet publish/Horinova.dll
```

## App data

History and settings are stored under `~/.config/Horinova/` on typical Linux systems.

## License / original source

The original Windows source files are included under `WindowsOriginal/` for reference. Review and add your preferred license before publishing the project publicly.

## Arch package publishing

A starter AUR recipe and publishing checklist are in `packaging/aur/`. Replace the GitHub placeholders, decide the project's license, and test the package in Arch before publishing.
