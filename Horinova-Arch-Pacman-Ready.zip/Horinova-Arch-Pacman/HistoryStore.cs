using System.Text.Json;

namespace Horinova;

internal sealed record HistoryEntry(string Url, DateTime VisitedAt);

internal static class HistoryStore
{
    private static readonly string Folder = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Horinova");
    private static readonly string FilePath = Path.Combine(Folder, "history.json");
    private static readonly object Gate = new();

    public static IReadOnlyList<HistoryEntry> Read()
    {
        lock (Gate)
        {
            try
            {
                if (!File.Exists(FilePath)) return Array.Empty<HistoryEntry>();
                return JsonSerializer.Deserialize<List<HistoryEntry>>(File.ReadAllText(FilePath)) ?? new();
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException)
            { return Array.Empty<HistoryEntry>(); }
        }
    }

    public static void Add(string? url)
    {
        if (!IsWebUrl(url)) return;
        lock (Gate)
        {
            try
            {
                Directory.CreateDirectory(Folder);
                var entries = Read().ToList();
                entries.Add(new HistoryEntry(url!, DateTime.Now));
                if (entries.Count > 2000) entries = entries.Skip(entries.Count - 2000).ToList();
                File.WriteAllText(FilePath, JsonSerializer.Serialize(entries,
                    new JsonSerializerOptions { WriteIndented = true }));
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException) { }
        }
    }

    public static void Clear()
    {
        lock (Gate)
        {
            try { if (File.Exists(FilePath)) File.Delete(FilePath); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }

    private static bool IsWebUrl(string? value) => Uri.TryCreate(value, UriKind.Absolute, out var uri) &&
        (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);
}
