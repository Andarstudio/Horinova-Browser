#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
dotnet restore Horinova.Arch.csproj
dotnet publish Horinova.Arch.csproj -c Release -r linux-x64 --self-contained false -o publish
printf '\nBuild complete. Run with: dotnet publish/Horinova.dll\n'
printf 'Install runtime dependencies on Arch: sudo pacman -S --needed dotnet-runtime gtk3 webkit2gtk-4.1 libsoup3\n'
