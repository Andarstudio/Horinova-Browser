using System.Net.Http;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;

namespace Horinova;

public sealed class MainWindow : Window
{
    private readonly TextBox _address = new() { Watermark = "Search or enter a website", VerticalContentAlignment = VerticalAlignment.Center };
    private readonly TextBlock _status = new() { Text = "Horinova · Arch Edition", Margin = new Thickness(10, 4) };
    private readonly TabControl _tabs = new();
    private readonly Dictionary<NativeWebView, bool> _privateTabs = new();
    private int _tabCount;
    private string _homeUrl = "https://duckduckgo.com/";
    private static readonly string SettingsFolder = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Horinova");
    private static readonly string SettingsPath = Path.Combine(SettingsFolder, "settings.json");

    public MainWindow()
    {
        Title = "Horinova — Arch Edition";
        Width = 1280;
        Height = 820;
        MinWidth = 800;
        MinHeight = 560;
        LoadSettings();

        var root = new Grid { RowDefinitions = new RowDefinitions("Auto,Auto,Auto,*,Auto") };
        var header = new Border
        {
            Background = Brush("#171A22"),
            Padding = new Thickness(14, 8),
            Child = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Spacing = 10,
                Children =
                {
                    new TextBlock { Text = "◈", FontSize = 23, Foreground = Brush("#8AB4F8"), VerticalAlignment = VerticalAlignment.Center },
                    new TextBlock { Text = "HORINOVA", FontSize = 18, FontWeight = FontWeight.Bold, VerticalAlignment = VerticalAlignment.Center },
                    new TextBlock { Text = "ARCH EDITION", FontSize = 11, Foreground = Brush("#9BA3B4"), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(2, 3, 0, 0) }
                }
            }
        };
        Grid.SetRow(header, 0);
        root.Children.Add(header);

        var menu = CreateMenu();
        Grid.SetRow(menu, 1);
        root.Children.Add(menu);

        var toolbar = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            Spacing = 5,
            Margin = new Thickness(8, 8, 8, 7),
            VerticalAlignment = VerticalAlignment.Center
        };
        toolbar.Children.Add(MakeButton("←", (_, _) => CurrentView()?.GoBack(), "Back"));
        toolbar.Children.Add(MakeButton("→", (_, _) => CurrentView()?.GoForward(), "Forward"));
        toolbar.Children.Add(MakeButton("⟳", (_, _) => CurrentView()?.Refresh(), "Reload"));
        toolbar.Children.Add(MakeButton("⌂", (_, _) => Navigate(_homeUrl), "Home"));
        _address.MinWidth = 250;
        _address.HorizontalAlignment = HorizontalAlignment.Stretch;
        _address.KeyDown += Address_KeyDown;
        toolbar.Children.Add(_address);
        toolbar.Children.Add(MakeButton("Go", (_, _) => NavigateFromAddress()));
        toolbar.Children.Add(MakeButton("+ Tab", (_, _) => NewTab()));
        toolbar.Children.Add(MakeButton("Private", (_, _) => NewTab(_homeUrl, true), "Private tab (best-effort isolation; see README)"));
        toolbar.Children.Add(MakeButton("× Tab", (_, _) => CloseCurrentTab(), "Close current tab"));
        Grid.SetRow(toolbar, 2);
        root.Children.Add(toolbar);

        _tabs.HorizontalAlignment = HorizontalAlignment.Stretch;
        _tabs.VerticalAlignment = VerticalAlignment.Stretch;
        _tabs.SelectionChanged += (_, _) => SyncAddress();
        Grid.SetRow(_tabs, 3);
        root.Children.Add(_tabs);

        var footer = new Border
        {
            Background = Brush("#171A22"),
            Child = _status
        };
        Grid.SetRow(footer, 4);
        root.Children.Add(footer);
        Content = root;
        OpenNewTab(_homeUrl, false);
    }

    private static IBrush Brush(string color) => new SolidColorBrush(Color.Parse(color));

    private static Button MakeButton(string label, EventHandler<RoutedEventArgs> action, string? tooltip = null)
    {
        var button = new Button { Content = label, Padding = new Thickness(10, 7), MinWidth = 36 };
        if (tooltip is not null) ToolTip.SetTip(button, tooltip);
        button.Click += action;
        return button;
    }

    private NativeWebView? CurrentView() => (_tabs.SelectedItem as TabItem)?.Content as NativeWebView;

    private void NewTab(string? url = null, bool privateMode = false) => OpenNewTab(url ?? _homeUrl, privateMode);

    private void OpenNewTab(string url, bool privateMode)
    {
        var web = new NativeWebView
        {
            Source = new Uri(url),
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        _privateTabs[web] = privateMode;
        web.NavigationStarted += (_, _) => _status.Text = privateMode ? "Private tab · Loading…" : "Loading…";
        web.NavigationCompleted += (_, e) =>
        {
            var current = web.Source?.ToString();
            if (current is not null)
            {
                if (!privateMode) HistoryStore.Add(current);
                if (ReferenceEquals(CurrentView(), web)) _address.Text = current;
            }
            _status.Text = privateMode
                ? (e.IsSuccess ? "Private tab · Ready · History not saved" : "Private tab · Page could not be loaded")
                : (e.IsSuccess ? "Ready" : "Page could not be loaded");
        };
        var tab = new TabItem { Header = privateMode ? $"◉ Private {_tabCount + 1}" : $"Tab {_tabCount + 1}", Content = web };
        _tabCount++;
        _tabs.Items.Add(tab);
        _tabs.SelectedItem = tab;
        _address.Text = url;
    }

    private void CloseCurrentTab()
    {
        if (_tabs.SelectedItem is not TabItem selected) return;
        if (selected.Content is NativeWebView web) _privateTabs.Remove(web);
        _tabs.Items.Remove(selected);
        if (_tabs.Items.Count == 0) NewTab();
        SyncAddress();
    }

    private static Uri ResolveAddress(string input)
    {
        var value = input.Trim();
        if (string.IsNullOrWhiteSpace(value)) return new Uri("https://duckduckgo.com/");
        if (Uri.TryCreate(value, UriKind.Absolute, out var absolute) &&
            (absolute.Scheme == Uri.UriSchemeHttp || absolute.Scheme == Uri.UriSchemeHttps)) return absolute;
        if (!value.Contains(' ') && value.Contains('.') && Uri.TryCreate("https://" + value, UriKind.Absolute, out var site)) return site;
        return new Uri("https://duckduckgo.com/?q=" + Uri.EscapeDataString(value));
    }

    private void NavigateFromAddress() => Navigate(_address.Text ?? string.Empty);

    private void Navigate(string address)
    {
        var target = ResolveAddress(address);
        if (CurrentView() is { } web) web.Navigate(target);
        else OpenNewTab(target.ToString(), false);
        _address.Text = target.ToString();
        _status.Text = "Loading…";
    }

    private void Address_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter) { NavigateFromAddress(); e.Handled = true; }
    }

    private void SyncAddress()
    {
        var web = CurrentView();
        if (web?.Source is not null) _address.Text = web.Source.ToString();
        if (web is not null && _privateTabs.TryGetValue(web, out var isPrivate) && isPrivate)
            _status.Text = "Private tab · History not saved";
    }

    private void LoadSettings()
    {
        try
        {
            if (File.Exists(SettingsPath))
            {
                using var doc = System.Text.Json.JsonDocument.Parse(File.ReadAllText(SettingsPath));
                if (doc.RootElement.TryGetProperty("homeUrl", out var home) && home.GetString() is { } value)
                    _homeUrl = ResolveAddress(value).ToString();
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.Text.Json.JsonException) { }
    }

    private void SaveSettings()
    {
        try
        {
            Directory.CreateDirectory(SettingsFolder);
            File.WriteAllText(SettingsPath, System.Text.Json.JsonSerializer.Serialize(new { homeUrl = _homeUrl },
                new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
    }

    private Menu CreateMenu()
    {
        var menu = new Menu;
        var history = new MenuItem { Header = "History" };
        history.Click += (_, _) => _ = ShowHistory();
        var downloads = new MenuItem { Header = "Downloads" };
        downloads.Click += (_, _) => _ = ShowDownloadDialog();
        var settings = new MenuItem { Header = "Settings" };
        settings.Click += (_, _) => _ = ShowSettingsDialog();
        var about = new MenuItem { Header = "About Horinova" };
        about.Click += (_, _) => _ = ShowAboutDialog();
        menu.Items.Add(history);
        menu.Items.Add(downloads);
        menu.Items.Add(settings);
        menu.Items.Add(about);
        return menu;
    }

    private async Task ShowHistory()
    {
        var entries = HistoryStore.Read().Reverse().Take(500).ToList();
        var list = new ListBox { ItemsSource = entries.Select(x => $"{x.VisitedAt:g}   {x.Url}").ToList(), MinWidth = 700, MinHeight = 360 };
        var open = new Button { Content = "Open selected", Margin = new Thickness(4) };
        var clear = new Button { Content = "Clear history", Margin = new Thickness(4) };
        var close = new Button { Content = "Close", Margin = new Thickness(4) };
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Children = { open, clear, close } };
        var panel = new DockPanel { Margin = new Thickness(12) };
        DockPanel.SetDock(buttons, Dock.Bottom); panel.Children.Add(buttons); panel.Children.Add(list);
        var dialog = new Window { Title = "Horinova History", Width = 760, Height = 470, Content = panel, WindowStartupLocation = WindowStartupLocation.CenterOwner };
        open.Click += (_, _) =>
        {
            if (list.SelectedItem is string line)
            {
                var url = line[(line.IndexOf("   ", StringComparison.Ordinal) + 3)..];
                Navigate(url); dialog.Close();
            }
        };
        clear.Click += (_, _) => { HistoryStore.Clear(); list.ItemsSource = Array.Empty<string>(); _status.Text = "History cleared"; };
        close.Click += (_, _) => dialog.Close();
        await dialog.ShowDialog(this);
    }

    private async Task ShowSettingsDialog()
    {
        var home = new TextBox { Text = _homeUrl, MinWidth = 430 };
        var save = new Button { Content = "Save", Margin = new Thickness(4) };
        var cancel = new Button { Content = "Cancel", Margin = new Thickness(4) };
        var panel = new StackPanel { Spacing = 10, Margin = new Thickness(16), Children =
            { new TextBlock { Text = "Home page URL" }, home, new TextBlock { Text = "Search uses DuckDuckGo when you type words." },
              new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Children = { save, cancel } } } };
        var dialog = new Window { Title = "Horinova Settings", Width = 540, Height = 190, Content = panel, WindowStartupLocation = WindowStartupLocation.CenterOwner };
        save.Click += (_, _) => { _homeUrl = ResolveAddress(home.Text ?? string.Empty).ToString(); SaveSettings(); _status.Text = "Settings saved"; dialog.Close(); };
        cancel.Click += (_, _) => dialog.Close();
        await dialog.ShowDialog(this);
    }

    private async Task ShowDownloadDialog()
    {
        var url = new TextBox { Watermark = "https://example.com/file.zip", MinWidth = 460 };
        var status = new TextBlock { Text = "Files are saved to ~/Downloads/Horinova" };
        var download = new Button { Content = "Download", Margin = new Thickness(4) };
        var cancel = new Button { Content = "Close", Margin = new Thickness(4) };
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Children = { download, cancel } };
        var panel = new StackPanel { Spacing = 10, Margin = new Thickness(16), Children = { new TextBlock { Text = "Download from URL" }, url, status, buttons } };
        var dialog = new Window { Title = "Horinova Downloads", Width = 560, Height = 220, Content = panel, WindowStartupLocation = WindowStartupLocation.CenterOwner };
        download.Click += async (_, _) =>
        {
            if (!Uri.TryCreate(url.Text?.Trim(), UriKind.Absolute, out var uri) ||
                (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
            { status.Text = "Enter a valid HTTP or HTTPS URL."; return; }
            download.IsEnabled = false;
            try
            {
                var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads", "Horinova");
                Directory.CreateDirectory(folder);
                var fileName = Path.GetFileName(Uri.UnescapeDataString(uri.AbsolutePath));
                if (string.IsNullOrWhiteSpace(fileName) || fileName is "." or "..") fileName = "download-" + DateTime.Now.ToString("yyyyMMdd-HHmmss");
                var destination = Path.Combine(folder, fileName);
                status.Text = "Downloading…";
                using var client = new HttpClient { Timeout = TimeSpan.FromMinutes(5) };
                using var response = await client.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead);
                response.EnsureSuccessStatusCode();
                await using var input = await response.Content.ReadAsStreamAsync();
                await using var output = File.Create(destination);
                await input.CopyToAsync(output);
                status.Text = $"Saved: {destination}";
                _status.Text = "Download complete";
            }
            catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or IOException or UnauthorizedAccessException)
            { status.Text = "Download failed: " + ex.Message; }
            finally { download.IsEnabled = true; }
        };
        cancel.Click += (_, _) => dialog.Close();
        await dialog.ShowDialog(this);
    }

    private async Task ShowAboutDialog()
    {
        var close = new Button { Content = "Close", HorizontalAlignment = HorizontalAlignment.Right };
        var panel = new StackPanel { Spacing = 10, Margin = new Thickness(18), Children =
        {
            new TextBlock { Text = "◈ HORINOVA", FontSize = 22, FontWeight = FontWeight.Bold },
            new TextBlock { Text = "Arch Edition · 0.2.0" },
            new TextBlock { Text = "A browser shell using Avalonia and the system WebKit engine." },
            new TextBlock { Text = "This is an early port; not all Windows features are implemented." },
            close
        }};
        var dialog = new Window { Title = "About Horinova", Width = 420, Height = 220,
            WindowStartupLocation = WindowStartupLocation.CenterOwner, Content = panel };
        close.Click += (_, _) => dialog.Close();
        await dialog.ShowDialog(this);
    }

}

