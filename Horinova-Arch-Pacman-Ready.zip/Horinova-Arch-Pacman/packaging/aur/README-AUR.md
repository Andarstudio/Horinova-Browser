# Publishing Horinova to the AUR

This folder contains a starter AUR `PKGBUILD`. It is a template and has not been built or verified in a clean Arch environment.

## Before publishing

1. Push the complete Linux project to a public GitHub repository.
2. Create a GitHub release/tag named `v0.2.0` (the tag must match `pkgver` in `PKGBUILD`).
3. Replace `YOUR_USERNAME` and `YOUR_REPOSITORY` in `PKGBUILD` with the real GitHub account and repository.
4. Review the project's license and replace `license=('unknown')` with the correct license. Do not claim a license that you have not chosen.
5. Test in Arch Linux: `makepkg -si`. Fix all build/package warnings and errors before publishing.
6. Create an AUR account, create the `horinova` package, clone its AUR Git URL, then copy `PKGBUILD` into that cloned directory.
7. In the AUR clone, run `makepkg --printsrcinfo > .SRCINFO`, review it, then commit both `PKGBUILD` and `.SRCINFO` and push.

Users install it with an AUR helper, for example `yay -S horinova`. AUR packages are community-maintained recipes; this does not make Horinova available from the official repositories, and `pacman -S horinova` alone will not work unless users configure a repository that contains the package.

## Important

- This recipe builds the app from the tagged GitHub source and publishes a self-contained .NET Linux x64 app. It still requires native GTK/WebKitGTK libraries.
- This is an initial template, not a verified release. Test the result on a clean Arch install before publishing.
- The repository source must contain the project files at its root, including `Horinova.Arch.csproj`, `Horinova.desktop`, `MainWindow.cs`, `Program.cs`, `App.axaml`, and `Assets/`.
